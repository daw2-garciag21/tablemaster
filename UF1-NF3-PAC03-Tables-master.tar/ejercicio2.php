<?php
//connect to mysqli
$db = mysqli_connect(gethostname(), 'root', 'root') or 
    die ('Unable to connect. Check your connection parameters.');

// make sure you're using the right database
mysqli_select_db($db,'moviesite') or die(mysqli_error($db));

// retrieve information

function operacion($movie){
global $db;

$query = 'SELECT TRUNCATE(AVG(review_rating),2) AS average
    FROM
        reviews,movie
    WHERE
        review_movie_id='.$movie;
    
    $result=mysqli_query($db,$query)or die(mysqli_error($db));

    $row = mysqli_fetch_assoc($result);
    extract($row);
    
    return'<p>'. $average.'</p>';
}
