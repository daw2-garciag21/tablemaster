<html>
    <head>
    <title>Documento</title>
    <body>
        <ol>
            <li>He aprendido el select *from en sql</li>
            <li>He aprendido a hacer la media</li>
            <li>He aprendido a poner de color una fila</li>
            <li>He aprendido a hacer una tabla donde hayan filas con diferentes colores</li>
            <li>He aprendido a poner un contador de estrellas</li>
            <li>Como crear relaciones en php</li>
            <li>Hacer que podamos acceder a diferentes páginas dentro de una</li>
            <li>Como insertar datos en una tabla en php</li>
            <li>he aprendido algo más de bucles</li>
            <li>aprender como usar comando para conectarse a la base de datos en php</li>
        </ol>
        <p>Documento 5 y la explicación del profe un 5</p>
        <p>8</p>
        <p>Ejercicios muy dificiles y el 3 para mi era imposible porque no logro saber como hacerlo y lo he intentado</p>
    </body>
    </head>
</html>
