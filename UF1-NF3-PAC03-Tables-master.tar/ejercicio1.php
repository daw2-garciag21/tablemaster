<?php
//connect to mysqli
$db = mysqli_connect(gethostname(), 'root', 'root') or 
    die ('Unable to connect. Check your connection parameters.');

// make sure you're using the right database
mysqli_select_db($db,'moviesite') or die(mysqli_error($db));

// retrieve information

$query = <<<ENDSQL
INSERT INTO reviews
    (review_movie_id, review_date, reviewer_name, review_comment, review_rating)
VALUES
(2, "2018-05-06", "Jose Luis Torrente", "Torrente 4 mejor película de la saga", 7),
(3, "2018-05-24", "Roronoa Zoro", "Transmito mis sentimientos a través de mi espada", 5),
(6, "2018-07-19", "Trafalgar Law", "Los débiles no eligen para morir", 4),
(8, "2018-05-30", "Doraemon", "Això es el casquet volador", 6),
(3, "2018-04-06", "Luffy", "Un hombre sin sueños propios no puede destruir los de otros", 7),
(3, "2018-05-24", "Detective Conan", "Besto anime de detectives", 5),
(4, "2018-05-22", "Vaquilla", "Tú eres el vaquilla, alegre bandolero", 4),
(3, "2018-05-11", "Black Clover", "Así es besto shonen", 5),
(3, "2018-05-24", "Gta 5", "Gran pedazo de juego", 6)

ENDSQL;

mysqli_query($db,$query)or die(mysqli_error($db));

echo 'Movie database successfully updated!';